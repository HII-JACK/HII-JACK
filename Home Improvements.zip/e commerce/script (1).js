const mobileNav = document.querySelector(".hamburger");
const navbar = document.querySelector(".menubar");

const toggleNav = () => {
  navbar.classList.toggle("active");
  mobileNav.classList.toggle("hamburger-active");
};
mobileNav.addEventListener("click", () => toggleNav());

// Navbar *************************
document.addEventListener('DOMContentLoaded', function() {
  const navLinks = document.querySelectorAll('nav ul li a');

  navLinks.forEach(link => {
      link.addEventListener('click', function(event) {
          // Prevent default behavior
          event.preventDefault();

          // Remove the active class from all links
          navLinks.forEach(nav => nav.classList.remove('active'));

          // Add the active class to the clicked link
          this.classList.add('active');
      });
  });
});



// /************************** */
document.addEventListener("DOMContentLoaded", function() {
  const icons = document.querySelectorAll('.icon');
  let activeIcon = null; // Track the currently active icon

  icons.forEach(icon => {
    icon.addEventListener('click', function(event) {
      // Prevent the click event from propagating to the document
      event.stopPropagation();

      // Remove clicked class from the previously active icon, if any
      if (activeIcon && activeIcon !== this) {
        activeIcon.classList.remove('clicked');
      }

      // Add clicked class to the clicked icon
      this.classList.add('clicked');
      activeIcon = this; // Update the active icon
    });
  });

  // Remove the clicked class from all icons if clicking outside of them
  document.addEventListener('click', function() {
    if (activeIcon) {
      activeIcon.classList.remove('clicked');
      activeIcon = null; // Reset the active icon
    }
  });
});



/******************************************************* */
